function M2VerilogA(fname,opts)
% Generates a multiport passive model from S/Y/Z parameter data which can
% be incorporated into time domain simulations
% e.g. M2VerilogA('FreqResp.s2p') 
%           generates verilogA file 'FreqResp.va' containing model for
%           given data
% 
% INPUTS: 
% fname ... name of input data file. 
%           Input file can either be in 'Touchstone Format (.snp)' OR
%           in '.mat' file. The '.mat' file should contain Z-parameters
%           in the form of following variables
%           Z   - M x M x N matrix
%           freq- N x 1 vector
%                 where: M=number of ports, N=number of samples
%           
% opts  ... Options to control model parameters
%       opts.N: Order of approximation
% OUTPUT:
%   Generates verilogA file (same name as fname) 
%   containing model for given data.
%  
% Author:Zohaib Mahmood (zohaib@mit.edu)
% Date: June-21, 2010
% Copyright (C)  2010  ZOHAIB MAHMOOD



%================================================
%=           Processing Input Arguments         =
%================================================
warning off all

if nargin<1,
    warning('Input file name missing, using default test file');
    fname='test.mat';
end
alg='VF';
def.poletype='lincmplx';
def.weightparam=5; %5 --> weighting with inverse magnitude norm
def.Niter1=15;    %Number of iterations for fitting sum of elements (fast!) 
def.Niter2=10;    %Number of iterations for matrix fitting 
def.asymp=2;      %Fitting includes D   
def.logx=0;       %=0 --> Plotting is done using linear abscissa axis 
def.cmplx_ss=0;
def.NStop=100;
def.NStart=1;
def.MaxPercentError=0.5;
poles=[];

% Loading default values for undefined options
if nargin<2
  opts=def;
else 
  %Merge default values into opts  
  A=fieldnames(def);    
  for m=1:length(A)
    if ~isfield(opts,A(m))
      dum=char(A(m)); dum2=getfield(def,dum); opts=setfield(opts,dum,dum2);
    end
  end  
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if strcmp(fname(end-3:end), '.mat')
    load(fname) % fname contains Z and freq
    if(~exist('Z','var')) 
        error ('Variable "Z" does not exist in the .mat file'); 
    end
    if(~exist('freq','var')) 
        error ('Variable "freq" does not exist in the .mat file'); 
    end    
else
    data = read(rfdata.data, fname);    
    freq = data.Freq;
    Z= extract(data,'Z_PARAMETERS');
end

%================================================
%=           Z must be Symmetric                =
%================================================
Z_sym=Z;
freq=freq(:);
for i=1:size(Z,3)
    Z_sym(:,:,i)=0.5*(Z(:,:,i)+Z(:,:,i).');
end
bigY=Z_sym;
s=2*pi*1i*freq';

numFreqPoints1=size(bigY,3);
numFreqPoints2=length(s);
if (numFreqPoints1~=numFreqPoints2), 
    error(['Dimension mismatch between frequency and parameters,' ...
        'see "help M2VerilogA" for details']);
end
%================================================
%=           POLE-RESIDUE FITTING               =
%================================================ 
%%% finding number of poles for given error bound
if ~isfield(opts,'N')
    rmsdata=norm(bigY(:))/sqrt(length(bigY(:)));
    U=opts.NStop;
    L=opts.NStart;
    disp(['opts.N does not exist, searching for N between ' ...
        num2str(L) ' and ' num2str(U)]);
    while U-1 > L
        opts.N=ceil(0.5*(L+U));
        disp('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%');
        disp(['Trying opts.N=' num2str(opts.N)]);
        disp('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%');
        
        [SER,rmserr,bigYfit,opts2]=VFdriver(bigY,s,poles,opts);
        percenterror=rmserr*100/rmsdata;
        disp(['Percentage Error=' num2str(percenterror)]);
        if(percenterror<opts.MaxPercentError) U=opts.N;
        else L=opts.N; end
    end
    if(percenterror>opts.MaxPercentError) 
        opts.N=U;
        [SER,rmserr,bigYfit,opts2]=VFdriver(bigY,s,poles,opts);
        percenterror=rmserr*100/rmsdata;
        disp(['Percentage Error=' num2str(percenterror)]);
    end
    disp(['Generating Model with opts.N=' num2str(opts.N)]);
    if (opts.N>=opts.NStop) 
        disp('Reached limit, increase opts.NStop');
    end
else
    [SER,rmserr,bigYfit,opts2]=VFdriver(bigY,s,poles,opts);
end
    
Hvfit=ss(SER.A, SER.B, SER.C, SER.D);
%================================================
%=           Passivity Enforcement              =
%================================================ 
clear opts;
if strcmp(alg,'ltid')
    poles=SER.poles;
    MAX=ltid_best3(Z_sym,freq,poles);
    Hpvfit=MAX.Hss;
else
opts.Niter_out=15;
opts.Niter_in=10;
opts.cmplx_ss=0;
[SER,bigYfit_passive,opts3]=RPdriver(SER,s,opts);

Hpvfit=ss(SER.A, SER.B, SER.C, SER.D);
%=================================================
%= Comparing final model with given data         =
%=================================================
figure(11),
Nc=length(SER.D);
for row=1:Nc
  for col=row:Nc  
    dum1=squeeze(Z_sym(row,col,:));
    dum2=squeeze(bigYfit_passive(row,col,:));
    h1=semilogy(s/(2*pi*1i),abs(dum1),'g.'); hold on
    h2=semilogy(s/(2*pi*1i),abs(dum2),'r--');     
    h3=semilogy(s/(2*pi*1i),abs(dum2-dum1),'g-');         
  end
end 
hold off
xlabel('Frequency [Hz]'); ylabel('Immitance [Ohms or S]');
legend([h1 h2 h3],'Given data','Final model','Deviation');
end
%=================================================
%= Generating VerilogA file                      =
%=================================================

disp('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%');
disp(['Writing VerilogA file: ' fname(1:find(fname=='.')-1) '.va']);
disp('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%');
Z2VerilogA (Hpvfit,fname(1:find(fname=='.')-1))

disp('If NOT satisfied with final model, use input ')
disp('argument "opts" to change default model parameters in')
disp('either of the following way:') 
disp(['(1) Decrease opts.MaxPercentError, (current value:' num2str(opts2.MaxPercentError) ' )'])
disp(['(2) Increase opts.N, (current value:' num2str(opts2.N) ' )'])

warning on all
1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%           INTERNAL FUNCTIONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%           Z2VerilogA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Z2VerilogA (Sys,filename)
% This function converts a state space representation into
% an equivalent verilogA representation
A=Sys.a; B=Sys.b; C=Sys.c; D=Sys.d; 
fname=[filename '.va'];
fid=fopen(fname,'w');

ports=size(Sys); ports=ports(1);



header=['`include "constants.vams" \n'];
fprintf(fid,header);
header=['`include "disciplines.vams" \n \n'];
fprintf(fid,header);

header=['module ' filename '('];

for i=1:ports;
    header=[header ' p' int2str(i) 'p,' ];
    if i~=ports, header=[header ' p' int2str(i) 'n,' ];
    else header=[header ' p' int2str(i) 'n); \n' ]; end        
end

header=[header '\n'];
fprintf(fid,header);
% inout inout pos, neg;
header=['inout ' ];
for i=1:ports;
    header=[header ' p' int2str(i) 'p,' ];
    if i~=ports, header=[header ' p' int2str(i) 'n,' ];
    else header=[header ' p' int2str(i) 'n; \n' ]; end        
end
fprintf(fid,header);
% electrical pos, neg;
header=['electrical ' ];
for i=1:ports;
    header=[header ' p' int2str(i) 'p,' ];
    if i~=ports, header=[header ' p' int2str(i) 'n,' ];
    else header=[header ' p' int2str(i) 'n; \n' ]; end        
end
fprintf(fid,header);

%Writing A matrix
for i=1:size(A,1)
    for j=1:size(A,2)
        if A(i,j)~=0,
        fprintf(fid,['parameter real A' int2str(i) '_' int2str(j) ...
            sprintf(' = %1.16e',A(i,j)) '; \n']);
        end
    end
end

%Writing B matrix
for i=1:size(B,1)
    for j=1:size(B,2)
        if B(i,j)~=0,
        fprintf(fid,['parameter real B' int2str(i) '_' int2str(j) ...
            sprintf(' = %1.16e',B(i,j)) '; \n']);
        end
    end
end

%Writing C matrix
for i=1:size(C,1)
    for j=1:size(C,2)
        if C(i,j)~=0,
        fprintf(fid,['parameter real C' int2str(i) '_' int2str(j) ...
            sprintf(' = %1.16e',C(i,j)) '; \n']);
        end
    end
end

%Writing D matrix
for i=1:size(D,1)
    for j=1:size(D,2)
        if D(i,j)~=0,
        fprintf(fid,['parameter real D' int2str(i) '_' int2str(j) ...
            sprintf(' = %1.16e',D(i,j)) '; \n']);
        end
    end
end
fprintf(fid,['\n']);

states=size(A,1);
header=['electrical '];
for i=1:states
    if i~=states, header=[header ' X' int2str(i) ','];
    else header=[header ' X' int2str(i) '; \n']; end
end
fprintf(fid,header);

% writing U1,U2 etc
header=['real '];
for i=1:size(B,2)
    if i~=size(B,2), header=[header ' U' int2str(i) ','];
    else header=[header ' U' int2str(i) '; \n']; end
end
fprintf(fid,[header '\n']);

% analog begin
fprintf(fid,'analog begin \n \n');
% declaring inputs as U1, U2 etc
for i=1:size(B,2)
    fprintf(fid,['U' int2str(i) ' = I( p' int2str(i) 'p , p' int2str(i) 'n );\n']);
end


for i=1:states;
        header=['V(X' int2str(i) ') : ddt(V(X' int2str(i) '))== '];
        for j=1:states
            if A(i,j)~=0,
            header=[header ' + A' int2str(i) '_' int2str(j) '*V(X' int2str(j) ')'];
            end
        end
        for j=1:size(B,2)
            if B(i,j)~=0,
            header=[header ' + B' int2str(i) '_' int2str(j) '*(U' int2str(j) ')'];
            end
        end
        fprintf(fid,[header ';\n']);
end
    
% Writing outputs

for i=1:size(C,1);
        header=['V( p' int2str(i) 'p , p' int2str(i) 'n) <+ '];
        for j=1:states
            if C(i,j)~=0,
            header=[header ' + C' int2str(i) '_' int2str(j) '*V(X' int2str(j) ')'];
            end
        end
        for j=1:size(D,2)
            if D(i,j)~=0,
            header=[header ' + D' int2str(i) '_' int2str(j) '*(U' int2str(j) ')'];
            end
        end
        fprintf(fid,[header ';\n']);
 end

fprintf(fid,'end \n');
fprintf(fid,'endmodule'); 
fclose(fid);
1;