% This file demonstrates various features of M2VerilogA

%% EXAMPLE #1 - 3-port, .mat file 
% This example demonstrates how M2VerilogA can be used with 
% minimal options.
% Input file: 'test.mat', containing Z-Parameters
% for a 3 port structure
% The algorithm first searches for minimum number of system
% poles using a binary search algorithm between 1-100 poles
% to achieve a preset error bound of 0.5% on the mismatch

M2VerilogA('test.mat');
disp('---- EXAMPLE 1 COMPLETE ----')
input('Press ENTER to continue ...');

%% EXAMPLE #2 - 3-port, .mat file
% This example demonstrates how various options of M2VerilogA can be used
% Input file: 'test.mat', containing Z-Parameters
% for a 3 port structure
% 
% In the following example we search for minimun number of poles between
% 1-20 to achieve and error bound of 1%
opts.NStop=20;
opts.NStart=1;
opts.MaxPercentError=1;
M2VerilogA('test.mat',opts);
disp('---- EXAMPLE 2 COMPLETE ----')
input('Press ENTER to continue ...');

%% EXAMPLE #3 - 3-port, .mat file 
% In the previous example the algorithm found N=7
% if we know how many poles we want in the system, we can 
% directly supply the value of N as follows
opts.N=7;
M2VerilogA('test.mat',opts);
disp('---- EXAMPLE 3 COMPLETE ----')
input('Press ENTER to continue ...');

%% EXAMPLE #4 - 9-port, .s9p file 
% In this example we use S-parameter file in touchstone format ('.s9p')
% to generate the model.
% This example may take substantial time to run
opts.N=9;
M2VerilogA('SParameters9Ports.s9p',opts);
disp('---- EXAMPLE 4 COMPLETE ----')
input('Press ENTER to continue ...');
